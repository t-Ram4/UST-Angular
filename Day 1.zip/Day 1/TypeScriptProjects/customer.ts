export interface Customer {
    name: string;
    id: number;
  }