"use strict";
exports.__esModule = true;
var deptObj = {
    name: "Electrical",
    id: 100
};
console.log(deptObj);
