let someArray = [1, "Ram", "CTS"];
for (let entry of someArray) {
  console.log(entry); // 1, "string", false
}