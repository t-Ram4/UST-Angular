import { Customer } from "./customer";

let cusObj:Customer={

    name:"John",
    id:100

}

console.log(cusObj);