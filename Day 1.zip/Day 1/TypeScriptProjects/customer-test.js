"use strict";
exports.__esModule = true;
var cusObj = {
    name: "John",
    id: 100
};
console.log(cusObj);
