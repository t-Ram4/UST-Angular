

import { Student } from "./student";
class StudentTest {
    
        student: Student;
       
        
        constructor(student: Student ) {
            this.student = student;
            
        }
        display():void {
            console.log("Studnet name = " + this.student.name +  ", student id = " + this.student.id);
        }

    }
    let stud:Student={name:"Jone",id:100,dept:{name:"el",id:1}};
    let studTest =new StudentTest(stud);
    studTest.display();
    console.log(studTest)