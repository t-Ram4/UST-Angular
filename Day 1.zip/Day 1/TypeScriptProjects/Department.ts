export interface Department {
    name: string;
    id: number;
  }