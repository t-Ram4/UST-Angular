var UserAccount1 = /** @class */ (function () {
    function UserAccount1(name, id) {
        this.name = name;
        this.id = id;
    }
    return UserAccount1;
}());
var user1 = new UserAccount1("Murphy", 1);
