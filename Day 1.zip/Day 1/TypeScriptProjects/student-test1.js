"use strict";
exports.__esModule = true;
var StudentTest = /** @class */ (function () {
    function StudentTest(student) {
        this.student = student;
    }
    StudentTest.prototype.display = function () {
        console.log("Studnet name = " + this.student.name + ", student id = " + this.student.id);
    };
    return StudentTest;
}());
var stud = { name: "Jone", id: 100, dept: { name: "el", id: 1 } };
var studTest = new StudentTest(stud);
studTest.display();
console.log(studTest);
